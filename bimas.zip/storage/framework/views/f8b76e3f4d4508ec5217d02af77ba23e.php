<body>
    <div id="app">
        <div id="sidebar" class='active'>
            <div class="sidebar-wrapper active">
    <div class="sidebar-header">
        <img src="<?php echo e(asset('voler/assets/images/logo-bimas.svg')); ?>" alt="" srcset="" class="img-fluid">
    </div>
    <div class="sidebar-menu">
        <ul class="menu">
            
                
            
            
            
            <li class="sidebar-item <?php echo $__env->yieldContent('dashboard'); ?> ">
                
                <a href="<?php echo e(route('dashboard')); ?>" class='sidebar-link'>
                    <i data-feather="home" width="20"></i> 
                    <span>Dashboard</span>
                </a>
                
            </li>
            
            
            <li class='sidebar-title'>Layanan</li>
                
                <li class="sidebar-item has-sub <?php echo $__env->yieldContent('sub-layanan'); ?>">

                    <a href="#" class='sidebar-link <?php echo $__env->yieldContent('layanan'); ?>'>
                        <i data-feather="droplet" width="20"></i> 
                        <span>Layanan SKT dan Piagam Majelis Ta'lim</span>
                    </a>

                    
                    <ul class="submenu <?php echo $__env->yieldContent('skt-mt'); ?>">
                        
                        <li>
                            <a href="<?php echo e(route('skt_piagam_mt.index')); ?>">
                                    Surat Keterangan Terdaftar
                            </a>
                        </li>
                        
                        
                        
                    </ul>
                    
                </li>
                <li class='sidebar-title'>DATA MASTER</li>
                    <li class="sidebar-item  has-sub">

                        <a href="#" class='sidebar-link'>
                            <i data-feather="server" width="20"></i> 
                            <span>Data Kecamatan dan Kelurahan</span>
                        </a>

                        
                        <ul class="submenu ">
                            
                            <li>
                                <a href="<?php echo e(route('kecamatan.index')); ?>">Kecamatan</a>
                            </li>
                            
                            <li>
                                <a href="<?php echo e(route('kelurahan.index')); ?>">Kelurahan</a>
                            </li>                            
                        </ul>                        
                    </li>

                    <?php if(auth()->check() && (auth()->user()->hasRole('Admin'))): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('role.index')); ?>" class='sidebar-link'>
                            <i data-feather="shield" width="20"></i> 
                            <span>Manajemen Role</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('user.index')); ?>" class='sidebar-link'>
                            <i data-feather="users" width="20"></i> 
                            <span>Manajemen User</span>
                        </a>
                    </li>
                    <?php endif; ?>

                <li class='sidebar-title'>Tong Sampah</li>
                <li class="sidebar-item <?php echo $__env->yieldContent('trash'); ?>">
                    <a href="<?php echo e(route('skt_piagam_mt.trash')); ?>" class='sidebar-link'>
                            <i data-feather="book-open"></i>
                            <span>Majelis Taklim</span>
                    </a>
                </li>    
                
        </ul>
    </div>
    <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
</div>
        </div><?php /**PATH C:\laragon\www\bimas-mt\resources\views/include/sidebar.blade.php ENDPATH**/ ?>