<!-- FOOTER SEDERHANA -->
    <footer class="site-footer">
        <p>2025 &copy; created with ❤️ Kementerian Agama Kutai Kartanegara</p>
    </footer><?php /**PATH C:\laragon\www\bimas-mt\resources\views/include/footerv2.blade.php ENDPATH**/ ?>