

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Error</h4>
                </div>
                <div class="card-body">
                    <div class="alert alert-danger">
                        <h4>Terjadi Kesalahan</h4>
                        <p><?php echo e($message); ?></p>
                        <?php if(config('app.debug')): ?>
                        <hr>
                        <pre><?php echo e($trace); ?></pre>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Kembali</a>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\bimas-mt\resources\views/errors/custom.blade.php ENDPATH**/ ?>