
<?php $__env->startSection('title', 'Detail Kelurahan'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content container-fluid">
    <div class="page-title">
        <h3>Detail Kelurahan</h3>
    </div>
    
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Detail Kelurahan</h4>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label"><strong>Kecamatan</strong></label>
                        <p class="form-control-plaintext">
                            <span class="badge bg-info"><?php echo e($kelurahan->kecamatan->kecamatan); ?></span>
                        </p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><strong>Nama Kelurahan</strong></label>
                        <p class="form-control-plaintext"><?php echo e($kelurahan->nama_kelurahan); ?></p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><strong>Dibuat pada</strong></label>
                        <p class="form-control-plaintext"><?php echo e($kelurahan->created_at->format('d-m-Y H:i')); ?></p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><strong>Diperbarui pada</strong></label>
                        <p class="form-control-plaintext"><?php echo e($kelurahan->updated_at->format('d-m-Y H:i')); ?></p>
                    </div>

                    <div class="mb-3 d-flex gap-2">
                        <a href="<?php echo e(route('kelurahan.edit', $kelurahan->id)); ?>" class="btn btn-warning">
                            <i data-feather="edit"></i> Edit
                        </a>
                        <a href="<?php echo e(route('kelurahan.index')); ?>" class="btn btn-secondary">
                            <i data-feather="arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\bimas-mt\resources\views/backend/kelurahan/show.blade.php ENDPATH**/ ?>