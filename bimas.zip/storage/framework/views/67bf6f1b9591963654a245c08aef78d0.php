
<?php $__env->startSection('title', 'Surat Keterangan Terdaftar Majelis Ta\'lim'); ?>
<?php $__env->startSection('sub-layanan', 'active'); ?>
<?php $__env->startSection('layanan', 'active'); ?>
<?php $__env->startSection('skt-mt', 'active'); ?>

<?php $__env->startPush('css'); ?>
<style>
    .table td {
        white-space: nowrap;
        max-width: 200px;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content container-fluid">
    <div class="page-title">
        <h3>Surat Keterangan Terdaftar</h3>
    </div>
    
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Surat Keterangan Terdaftar</h4>
                </div>
                <div class="card-body">
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-2 mb-3">
                                <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Editor') || auth()->user()->hasRole('Operator')): ?>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#importExcelModal">
                                    <i data-feather="file-text"></i> <span class="d-none d-sm-inline">Import Excel</span>
                                </button>
                                <a href="<?php echo e(route('skt_piagam_mt.export')); ?>" class="btn btn-info">
                                    <i data-feather="download"></i> <span class="d-none d-sm-inline">Export Excel</span>
                                </a>
                                <a href="<?php echo e(route('skt_piagam_mt.create')); ?>" class="btn btn-primary">
                                    <i data-feather="plus"></i> <span class="d-none d-sm-inline">Tambah Majelis Ta'lim</span>
                                </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('skt_piagam_mt.rekap')); ?>" class="btn btn-info">
                                    <i data-feather="file"></i> <span class="d-none d-sm-inline">Rekapan Data</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Filter Data</h5>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('skt_piagam_mt.index')); ?>" method="GET">
                                        <div class="row">
                                            
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label for="kecamatan_filter">Kecamatan</label>
                                                    <select class="form-select" id="kecamatan_filter" name="kecamatan_id" onchange="getKelurahan()">
                                                        <option value="">Semua Kecamatan</option>
                                                        <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($kecamatan->id); ?>" <?php echo e(request('kecamatan_id') == $kecamatan->id ? 'selected' : ''); ?>>
                                                                <?php echo e(ucwords($kecamatan->kecamatan)); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label for="kelurahan_filter">Kelurahan</label>
                                                    <select class="form-select" id="kelurahan_filter" name="kelurahan_id">
                                                        <option value="">Semua Kelurahan</option>
                                                        <?php $__currentLoopData = $kelurahans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelurahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($kelurahan->id); ?>" <?php echo e(request('kelurahan_id') == $kelurahan->id ? 'selected' : ''); ?>>
                                                                <?php echo e($kelurahan->nama_kelurahan); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            
                                            <div class="col-md-2 d-flex align-items-end">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-primary me-2">
                                                        <i data-feather="filter"></i> Filter
                                                    </button>
                                                    <a href="<?php echo e(route('skt_piagam_mt.index')); ?>" class="btn btn-secondary">
                                                        <i data-feather="refresh-cw"></i> Reset
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered text-nowrap" id="table1">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nomor Statistik MT</th>
                                    <th>Nama Majelis Ta'lim</th>
                                    <th>Alamat</th>
                                    <th>Kelurahan</th>
                                    <th>Kecamatan</th>
                                    <th>Status</th>
                                    <th>Ketua</th>
                                    <th>No. HP</th>
                                    <th>Mendaftar</th>
                                    <th>Daftar Ulang</th>
                                    <th>Aksi</th>
                                    <th>SKT dan Piagam</th>
                                    <th>Berkas MT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sktpiagammts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->nomor_statistik); ?></td>
                                        <td><?php echo e($item->nama_majelis); ?></td>
                                        <td><?php echo e($item->alamat); ?></td>
                                        <td><?php echo e($item->kelurahan->nama_kelurahan); ?></td>
                                        <td><?php echo e(ucfirst($item->kecamatan->kecamatan)); ?></td>
                                        <td class="text-center">
                                            <?php if($item->status == 'aktif'): ?>
                                                <span class="badge bg-success">Aktif</span>
                                            <?php elseif($item->status == 'nonaktif'): ?>
                                                <span class="badge bg-danger">Non-Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Belum Update</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->ketua); ?></td>
                                        <td><?php echo e($item->no_hp); ?></td>
                                        <td><?php echo e($item->mendaftar); ?></td>
                                        <td><?php echo e($item->mendaftar_ulang); ?></td>
                                        <td class="text-wrap">
                                            <div class="btn-group btn-group-sm mb-2" role="group">
                                                
                                                <button type="button" 
                                                        class="btn btn-success d-inline-flex align-items-center" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#wilayahModal<?php echo e($item->id); ?>">
                                                    <i class="fa-regular fa-file-lines me-1"></i> Cetak SKT
                                                </button>

                                                <a href="<?php echo e(route('skt_piagam_mt.cetak_piagam', $item->id)); ?>" class="btn btn-warning d-inline-flex align-items-center" target="_blank">
                                                    <i class="fa-regular fa-file-lines me-1"></i> Cetak Piagam
                                                </a>
                                            </div>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Editor') || auth()->user()->hasRole('Operator')): ?>
                                                <a href="<?php echo e(route('skt_piagam_mt.edit', $item->id)); ?>" class="btn btn-success d-inline-flex align-items-center">
                                                    <i class="fa-regular fa-pen-to-square me-1"></i> Edit
                                                </a>
                                                <?php endif; ?>
                                                <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Operator')): ?>
                                                <button type="button" class="btn btn-danger d-inline-flex align-items-center" onclick="confirmDelete(<?php echo e($item->id); ?>)">
                                                    <i class="fa-regular fa-trash-can me-1"></i> Hapus
                                                </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>

                                        
                                        <td class="text-wrap">
                                            <div class="btn-group btn-group-sm mb-2 text-nowrap">
                                                <?php if(!$item->file_skt): ?>
                                                    <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Editor') || auth()->user()->hasRole('Operator')): ?>
                                                    <button type="button" class="btn btn-primary d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#uploadSktModal<?php echo e($item->id); ?>">
                                                        <i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Upload SKT
                                                    </button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <a href="<?php echo e(asset('storage/skt/' . $item->file_skt)); ?>" class="btn btn-success d-inline-flex align-items-center" target="_blank">
                                                        <i class="fa-regular fa-eye me-1"></i> Lihat SKT
                                                    </a>
                                                    <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Operator')): ?>
                                                    <button type="button" class="btn btn-danger d-inline-flex align-items-center" onclick="confirmDeleteSkt(<?php echo e($item->id); ?>)">
                                                        <i class="fa-regular fa-trash-can me-1"></i> Hapus SKT
                                                    </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="btn-group btn-group-sm text-nowrap">
                                                <?php if(!$item->file_piagam): ?>
                                                    <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Editor') || auth()->user()->hasRole('Operator')): ?>
                                                    <button type="button" class="btn btn-info d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#uploadPiagamModal<?php echo e($item->id); ?>">
                                                        <i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Upload Piagam
                                                    </button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <a href="<?php echo e(asset('storage/piagam/' . $item->file_piagam)); ?>" class="btn btn-success d-inline-flex align-items-center" target="_blank">
                                                        <i class="fa-regular fa-eye me-1"></i> Lihat Piagam
                                                    </a>
                                                    <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Operator')): ?>
                                                    <button type="button" class="btn btn-danger d-inline-flex align-items-center" onclick="confirmDeletePiagam(<?php echo e($item->id); ?>)">
                                                        <i class="fa-regular fa-trash-can me-1"></i> Hapus Piagam
                                                    </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>

                                        
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <?php if(!$item->file_berkas): ?>
                                                    <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Editor') || auth()->user()->hasRole('Operator')): ?>
                                                    <button type="button" class="btn btn-info d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#uploadBerkasModal<?php echo e($item->id); ?>">
                                                        <i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Upload Berkas
                                                    </button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <a href="<?php echo e(asset('storage/berkas/' . $item->file_berkas)); ?>" class="btn btn-success d-inline-flex align-items-center" target="_blank">
                                                        <i class="fa-regular fa-eye me-1"></i> Lihat Berkas
                                                    </a>
                                                    <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Editor') || auth()->user()->hasRole('Operator')): ?>
                                                    <button type="button" class="btn btn-danger d-inline-flex align-items-center" onclick="confirmDeleteBerkas(<?php echo e($item->id); ?>)">
                                                        <i class="fa-regular fa-trash-can me-1"></i> Hapus Berkas
                                                    </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>

                                    
                                    <div class="modal fade" id="uploadSktModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="uploadSktModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="uploadSktModalLabel<?php echo e($item->id); ?>">Upload Surat Keterangan Terdaftar</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('skt_piagam_mt.upload_skt')); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="skt_id" value="<?php echo e($item->id); ?>">
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="skt_file<?php echo e($item->id); ?>" class="form-label">Pilih File SKT</label>
                                                            <input type="file" class="form-control" id="skt_file<?php echo e($item->id); ?>" name="skt_file" accept=".pdf" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-primary">Upload</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="modal fade" id="uploadPiagamModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="uploadPiagamModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="uploadPiagamModalLabel<?php echo e($item->id); ?>">Upload Piagam</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('skt_piagam_mt.upload_piagam')); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="piagam_id" value="<?php echo e($item->id); ?>">
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="piagam_file<?php echo e($item->id); ?>" class="form-label">Pilih File Piagam</label>
                                                            <input type="file" class="form-control" id="piagam_file<?php echo e($item->id); ?>" name="piagam_file" accept=".pdf" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-primary">Upload</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="modal fade" id="uploadBerkasModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="uploadBerkasModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="uploadBerkasModalLabel<?php echo e($item->id); ?>">Upload Berkas</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('skt_piagam_mt.upload_berkas')); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="berkas_id" value="<?php echo e($item->id); ?>">
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="berkas_file<?php echo e($item->id); ?>" class="form-label">Pilih Berkas</label>
                                                            <input type="file" class="form-control" id="berkas_file<?php echo e($item->id); ?>" name="berkas_file" accept=".pdf" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-primary">Upload</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="wilayahModal<?php echo e($item->id); ?>" tabindex="-1" data-bs-backdrop="static" aria-labelledby="wilayahModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                            <form action="/skt_piagam_mt/<?php echo e($item->id); ?>/cetak-skt" method="GET" target="_blank">
                                                <div class="modal-header">
                                                <h5 class="modal-title" id="wilayahModalLabel<?php echo e($item->id); ?>">Pilih Tipe Wilayah</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>

                                                <div class="modal-body">
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="radio" name="tipe" id="tipeKelurahan<?php echo e($item->id); ?>" value="kelurahan" checked>
                                                    <label class="form-check-label" for="tipeKelurahan<?php echo e($item->id); ?>">Kelurahan</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="tipe" id="tipeDesa<?php echo e($item->id); ?>" value="desa">
                                                    <label class="form-check-label" for="tipeDesa<?php echo e($item->id); ?>">Desa</label>
                                                </div>
                                                </div>

                                                <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Selesai</button>
                                                <button type="submit" class="btn btn-primary">Cetak SKT</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="14" class="text-center">Tidak ada data</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    
                    
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Import Excel -->
<div class="modal fade" id="importExcelModal" tabindex="-1" aria-labelledby="importExcelModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="importExcelModalLabel">Import Data dari Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('skt_piagam_mt.import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="excel_file" class="form-label">Pilih File Excel</label>
                        <input type="file" class="form-control" id="excel_file" name="excel_file" accept=".xlsx, .xls, .csv" required>
                        <div class="form-text">Format yang didukung: .xlsx, .xls, .csv</div>
                    </div>
                    <div class="alert alert-info">
                        <i data-feather="info" class="me-1"></i> Pastikan format Excel sesuai dengan template yang ditentukan.
                        <a href="<?php echo e(route('skt_piagam_mt.template')); ?>" class="alert-link">Download template</a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Form untuk delete dengan ID dinamis -->
<?php $__currentLoopData = $sktpiagammts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form id="delete-form-<?php echo e($item->id); ?>" action="/skt_piagam_mt/<?php echo e($item->id); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<form id="delete-skt-form-<?php echo e($item->id); ?>" action="/skt_piagam_mt/delete-skt/<?php echo e($item->id); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<form id="delete-piagam-form-<?php echo e($item->id); ?>" action="/skt_piagam_mt/delete-piagam/<?php echo e($item->id); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<form id="delete-berkas-form-<?php echo e($item->id); ?>" action="/skt_piagam_mt/delete-berkas/<?php echo e($item->id); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Pastikan SweetAlert2 tersedia
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof Swal === 'undefined') {
            console.error('SweetAlert2 tidak dimuat dengan benar!');
        } else {
            console.log('SweetAlert2 berhasil dimuat');
        }
    });
    
    // Inisialisasi Select2 untuk dropdown filter
    $(document).ready(function() {
        $('#kecamatan_filter').select2({
            placeholder: "Pilih Kecamatan",
            allowClear: true
        });
        
        $('#kelurahan_filter').select2({
            placeholder: "Pilih Kelurahan",
            allowClear: true
        });
    });
    
    // Fungsi untuk mendapatkan kelurahan berdasarkan kecamatan
    function getKelurahan() {
        const kecamatanId = document.getElementById('kecamatan_filter').value;
        const kelurahanSelect = document.getElementById('kelurahan_filter');
        
        // Reset dropdown kelurahan
        kelurahanSelect.innerHTML = '<option value="">Semua Kelurahan</option>';
        
        if (kecamatanId) {
            fetch(`/api/kelurahans/${kecamatanId}`)
                .then(response => response.json())
                .then(data => {
                    data.forEach(kelurahan => {
                        const option = document.createElement('option');
                        option.value = kelurahan.id;
                        option.textContent = kelurahan.nama_kelurahan;
                        kelurahanSelect.appendChild(option);
                    });
                    
                    // Reinisialisasi Select2 setelah mengupdate opsi
                    $('#kelurahan_filter').trigger('change');
                })
                .catch(error => console.error('Error:', error));
        }
    }
    
    // Fungsi konfirmasi hapus
    function confirmDelete(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data yang dihapus akan masuk ke trash dan dapat dipulihkan kembali!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(`delete-form-${id}`).submit();
            }
        });
    }
    
    // Fungsi konfirmasi hapus file SKT
    function confirmDeleteSkt(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "File SKT akan dihapus secara permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(`delete-skt-form-${id}`).submit();
            }
        });
    }
    
    // Fungsi konfirmasi hapus file Piagam
    function confirmDeletePiagam(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "File Piagam akan dihapus secara permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(`delete-piagam-form-${id}`).submit();
            }
        });
    }
    
    // Fungsi konfirmasi hapus file Berkas
    function confirmDeleteBerkas(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "File Berkas akan dihapus secara permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(`delete-berkas-form-${id}`).submit();
            }
        });
    }
    
    // Fungsi cetak SKT dengan tipe wilayah
    // function cetakSkt(id) {
    //     const tipeKelurahan = document.getElementById(`tipeKelurahan${id}`).checked;
    //     const tipeDesa = document.getElementById(`tipeDesa${id}`).checked;
    //     let tipeWilayah = 'kelurahan';
        
    //     if (tipeDesa) {
    //         tipeWilayah = 'desa';
    //     }
        
    //     // Simpan URL yang akan dibuka di tab baru
    //     const url = `/skt_piagam_mt/${id}/cetak-skt?tipe=${tipeWilayah}`;
        
    //     // Dapatkan referensi modal
    //     const modalElement = document.getElementById(`wilayahModal${id}`);
        
    //     // Tambahkan event listener untuk mendeteksi saat modal selesai ditutup
    //     $(modalElement).on('hidden.bs.modal', function (e) {
    //         // Buka tab baru setelah modal benar-benar tertutup
    //         window.open(url, '_blank');
    //         // Hapus event listener setelah digunakan
    //         $(modalElement).off('hidden.bs.modal');
    //     });
        
    //     // Tutup modal menggunakan jQuery (lebih konsisten)
    //     $(modalElement).modal('hide');
        
    //     // Fallback jika event tidak terpicu
    //     setTimeout(() => {
    //         if ($(modalElement).hasClass('show')) {
    //             $(modalElement).modal('hide');
    //             window.open(url, '_blank');
    //         }
    //     }, 300);
        
    //     // Mencegah event default
    //     return false;
    // }

// function cetakSkt(id) {
//     // Dapatkan referensi elemen
//     const modalElement = document.getElementById(`wilayahModal${id}`);
//     const tipeDesa = document.getElementById(`tipeDesa${id}`);
    
//     // Tentukan tipe wilayah
//     const tipeWilayah = tipeDesa && tipeDesa.checked ? 'desa' : 'kelurahan';
//     const url = `/skt_piagam_mt/${id}/cetak-skt?tipe=${tipeWilayah}`;
    
//     let tabOpened = false;
    
//     // Fungsi untuk membersihkan modal dan backdrop
//     const cleanupModal = () => {
//         // Hapus semua backdrop
//         $('.modal-backdrop').remove();
//         // Reset body
//         $('body').removeClass('modal-open').css('padding-right', '');
//         // Reset modal
//         $(modalElement).removeClass('show').attr('style', '');
//     };
    
//     // Fungsi untuk membuka tab baru
//     const openNewTab = () => {
//         if (!tabOpened) {
//             tabOpened = true;
//             window.open(url, '_blank');
//         }
//     };
    
//     // Event listener untuk modal tertutup
//     $(modalElement).one('hidden.bs.modal', function() {
//         cleanupModal();
//         openNewTab();
//     });
    
//     // Tutup modal
//     $(modalElement).modal('hide');
    
//     // Fallback jika modal tidak menutup dengan benar
//     setTimeout(() => {
//         if ($(modalElement).hasClass('show') || $('.modal-backdrop').length) {
//             cleanupModal();
//             openNewTab();
//         }
//     }, 500);
    
//     return false;
// }

// function cetakSkt(id) {
//     const modalElement = document.getElementById(`wilayahModal${id}`);
//     const tipeDesa = document.getElementById(`tipeDesa${id}`);
//     const tipeWilayah = tipeDesa && tipeDesa.checked ? 'desa' : 'kelurahan';
//     const url = `/skt_piagam_mt/${id}/cetak-skt?tipe=${tipeWilayah}`;

//     let tabOpened = false;

//     // Fungsi membersihkan manual khusus Bootstrap 5.0.0
//     const cleanupModal = () => {
//         document.body.classList.remove('modal-open');
//         document.body.style.overflow = 'auto';
//         document.documentElement.style.overflow = 'auto';
//         document.body.style.paddingRight = '';
//         // Hapus semua backdrop sisa
//         document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
//         // Reset properti modal agar bisa dibuka ulang
//         modalElement.classList.remove('show');
//         modalElement.style.display = '';
//         modalElement.setAttribute('aria-hidden', 'true');
//     };

//     const openNewTab = () => {
//         if (!tabOpened) {
//             tabOpened = true;
//             window.open(url, '_blank');
//         }
//     };

//     // Tutup modal manual dulu
//     const modalInstance = bootstrap.Modal.getInstance(modalElement) 
//         || new bootstrap.Modal(modalElement);
//     modalInstance.hide();

//     // Tunggu sedikit biar animasi selesai, baru bersihkan & buka tab
//     setTimeout(() => {
//         cleanupModal();
//         openNewTab();
//     }, 400);
// }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\bimas-mt\resources\views/backend/skt_piagam_mt/index.blade.php ENDPATH**/ ?>