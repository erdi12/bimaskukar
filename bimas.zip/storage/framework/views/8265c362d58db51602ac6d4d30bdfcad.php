

<?php $__env->startSection('content'); ?>
<div class="main-content container-fluid">
    <div class="page-title">
        <h3>Tambah Data Majelis Ta'lim</h3>
    </div>
    <section id="multiple-column-form">
        <div class="row match-height">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Form Tambah Majelis Ta'lim</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" method="POST" action="<?php echo e(route('skt_piagam_mt.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            <label for="nomor_statistik">Nomor Statistik Majelis Ta'lim</label>
                                            <div class="input-group">
                                                <input type="text" id="nomor_statistik" class="form-control <?php $__errorArgs = ['nomor_statistik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nomor akan otomatis terisi setelah memilih kecamatan"
                                                    name="nomor_statistik" readonly required value="<?php echo e(old('nomor_statistik')); ?>">
                                                <button class="btn btn-outline-secondary" type="button" id="btn-edit-nomor">
                                                    <i class="bi bi-pencil"></i> Edit
                                                </button>
                                            </div>
                                            <?php $__errorArgs = ['nomor_statistik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <small class="text-muted">Nomor statistik akan otomatis terisi setelah memilih kecamatan</small>
                                            <div id="nomor-loading" class="mt-1" style="display: none;">
                                                <div class="spinner-border spinner-border-sm text-primary" role="status">
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                                <small class="ms-1">Mengambil nomor statistik...</small>
                                            </div>
                                            <div id="nomor-error" class="mt-1 text-danger" style="display: none;"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            <label for="nama_majelis">Nama Majelis Ta'lim</label>
                                            <input type="text" id="nama_majelis" class="form-control" placeholder="Nama Majelis Ta'lim"
                                                name="nama_majelis" required value="<?php echo e(old('nama_majelis')); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="alamat">Alamat Majelis Ta'lim (Tanpa Kelurahan dan Kecamatan)</label>
                                            <input type="text" id="alamat" class="form-control" placeholder="Alamat"
                                                name="alamat" required value="<?php echo e(old('alamat')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="kecamatan">Kecamatan</label>
                                            <select class="form-select" id="kecamatan" name="kecamatan_id" style="width: 100%;" required>
                                                <option value="">Pilih Kecamatan</option>
                                                <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($kecamatan->id); ?>" <?php echo e(old('kecamatan_id') == $kecamatan->id ? 'selected' : ''); ?>><?php echo e(ucwords($kecamatan->kecamatan)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="kelurahan">Kelurahan</label>
                                            <select class="form-select" id="kelurahan" name="kelurahan_id" style="width: 100%;" required>
                                                <option value="">Pilih Kelurahan</option>
                                                <!-- Kelurahan options will be populated via AJAX -->
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="tanggal-berdiri">Tanggal Berdiri</label>
                                            <input type="date" id="tanggal-berdiri" class="form-control" name="tanggal_berdiri" required value="<?php echo e(old('tanggal_berdiri')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="status" name="status" required>
                                                    <option value="">Pilih Status</option>
                                                    <option value="aktif" <?php echo e(old('status') == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                                                    <option value="nonaktif" <?php echo e(old('status') == 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
                                                    <option value="belum_update" <?php echo e(old('status') == 'nonaktif' ? 'selected' : ''); ?>>Belum Update</option>
                                                </select>
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="ketua">Nama Ketua</label>
                                            <input type="text" id="ketua" class="form-control" placeholder="Nama Ketua Majelis Ta'lim"
                                                name="ketua" required value="<?php echo e(old('ketua')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="no_hp">Nomor Handphone</label>
                                            <input type="text" id="no_hp" class="form-control" placeholder="Nomor Handphone Ketua Majelis Ta'lim"
                                                name="no_hp" required value="<?php echo e(old('no_hp')); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="mendaftar">Tanggal Mendaftar</label>
                                            <input type="date" id="mendaftar" class="form-control" name="mendaftar" required value="<?php echo e(old('mendaftar')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="mendaftar_ulang">Tanggal Mendaftar Ulang</label>
                                            <input type="date" id="mendaftar_ulang" class="form-control" name="mendaftar_ulang" required value="<?php echo e(old('mendaftar_ulang')); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                    <a href="<?php echo e(route('skt_piagam_mt.index')); ?>" class="btn btn-danger me-1 mb-1">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Inisialisasi Select2
    $('#kecamatan').select2({
        placeholder: "Pilih Kecamatan",
        allowClear: true
    });

    $('#kelurahan').select2({
        placeholder: "Pilih Kelurahan",
        allowClear: true
    });

    // Event handler untuk perubahan kecamatan
    $('#kecamatan').on('change', function() {
        var kecamatanId = $(this).val();
        console.log('Kecamatan changed:', kecamatanId);

        // Reset kelurahan
        $('#kelurahan').empty().append('<option value="">Pilih Kelurahan</option>').trigger('change');

        if (kecamatanId) {
            // Ambil kelurahan
            $.ajax({
                url: "/api/kelurahans/" + kecamatanId,
                type: "GET",
                dataType: 'json',
                success: function(data) {
                    console.log("Response kelurahan:", data);
                    
                    if (data && data.length > 0) {
                        $.each(data, function(index, kelurahan) {
                            $('#kelurahan').append(new Option(
                                kelurahan.nama_kelurahan,
                                kelurahan.id,
                                false,
                                false
                            ));
                        });
                    } else {
                        $('#kelurahan').append(new Option("Tidak ada kelurahan", "", false, false));
                    }
                    $('#kelurahan').trigger('change');
                },
                error: function(xhr) {
                    console.error("Error ambil kelurahan:", xhr.responseText);
                    $('#kelurahan').append(new Option("Error: Gagal mengambil data", "", false, false));
                }
            });

            // Loading nomor statistik
            $('#nomor-loading').show();
            $('#nomor-error').hide();

            // Ambil nomor statistik otomatis
            $.ajax({
                url: "/get-next-nomor-statistik",
                type: "GET",
                dataType: 'json',
                data: { kecamatan_id: kecamatanId },
                success: function(data) {
                    $('#nomor-loading').hide();
                    console.log("Response nomor statistik:", data);

                    if (data && data.nomor_statistik) {
                        $('#nomor_statistik').val(data.nomor_statistik);
                    } else {
                        $('#nomor-error').text('Nomor statistik tidak ditemukan').show();
                    }
                },
                error: function(xhr) {
                    $('#nomor-loading').hide();
                    console.error("Error nomor statistik:", xhr.responseText);
                    $('#nomor-error').text('Gagal ambil nomor statistik').show();
                }
            });
        } else {
            $('#nomor_statistik').val('');
        }
    });

    // Inisialisasi data lama jika ada
    const oldKecamatanId = "<?php echo e(old('kecamatan_id')); ?>";
    if (oldKecamatanId) {
        $('#kecamatan').val(oldKecamatanId).trigger('change');
        
        setTimeout(function() {
            const oldKelurahanId = "<?php echo e(old('kelurahan_id')); ?>";
            if (oldKelurahanId) {
                $('#kelurahan').val(oldKelurahanId).trigger('change');
            }
        }, 500);
    }

    // Tombol edit nomor statistik
    $('#btn-edit-nomor').html('<i class="bi bi-pencil"></i> Edit');
    
    $('#btn-edit-nomor').on('click', function() {
        var $input = $('#nomor_statistik');
        if ($input.prop('readonly')) {
            $input.prop('readonly', false);
            $(this).html('<i class="bi bi-check"></i> Selesai');
        } else {
            $input.prop('readonly', true);
            $(this).html('<i class="bi bi-pencil"></i> Edit');
        }
    });
    
    // Auto-fill tanggal mendaftar ulang
    $('#mendaftar').on('change', function() {
        var tanggalMendaftar = new Date($(this).val());
        if (!isNaN(tanggalMendaftar.getTime())) {
            var tanggalMendaftarUlang = new Date(tanggalMendaftar);
            tanggalMendaftarUlang.setFullYear(tanggalMendaftar.getFullYear() + 5);
            
            var tahun = tanggalMendaftarUlang.getFullYear();
            var bulan = (tanggalMendaftarUlang.getMonth() + 1).toString().padStart(2, '0');
            var tanggal = tanggalMendaftarUlang.getDate().toString().padStart(2, '0');
            
            $('#mendaftar_ulang').val(`${tahun}-${bulan}-${tanggal}`);
        }
    });
});
</script>
<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\bimas-mt\resources\views/backend/skt_piagam_mt/create.blade.php ENDPATH**/ ?>